/*! ========================================================================
 * typography.js
 * Page/renders: components-typography.html
 * Plugins used: prettify
 * ======================================================================== */
$(function () {
    // Prettify
    // ================================
    prettyPrint();
});