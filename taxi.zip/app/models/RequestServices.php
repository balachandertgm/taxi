<?php

class RequestServices extends Eloquent {

    protected $table = 'request_services';

}
