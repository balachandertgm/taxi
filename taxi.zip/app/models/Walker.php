<?php

class Walker extends Eloquent {

    protected $table = 'walker';

}
