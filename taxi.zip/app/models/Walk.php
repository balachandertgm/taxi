
<?php

class Walk extends Eloquent {

    protected $table = 'walk';

    

}
