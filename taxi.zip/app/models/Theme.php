<?php

class Theme extends Eloquent {

    protected $table = 'theme';

}
?>