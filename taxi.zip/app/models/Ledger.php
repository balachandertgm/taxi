
<?php

class Ledger extends Eloquent {

    protected $table = 'ledger';

}
