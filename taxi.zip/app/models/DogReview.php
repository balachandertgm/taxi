<?php

class DogReview extends Eloquent {

    protected $table = 'review_dog';

}
