<?php

class ProviderType extends Eloquent {

    protected $table = 'walker_type';

}
