<?php

class WalkerDocument extends Eloquent {

    protected $table = 'walker_documents';

}
