<?php

class ProviderServices extends Eloquent {

    protected $table = 'walker_services';

}
