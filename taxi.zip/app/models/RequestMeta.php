<?php

class RequestMeta extends Eloquent {

    protected $table = 'request_meta';

}
