<?php

class Information extends Eloquent {

    protected $table = 'information';

}
