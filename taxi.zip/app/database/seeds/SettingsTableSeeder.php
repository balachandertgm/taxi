<?php
class SettingsTableSeeder extends Seeder {

    public function run()
    {
        Settings::create(array('id' => 1,'tool_tip' => 'Defalt search radius to look for providers','page'=>'1','key' => 'default_search_radius' , 'value' => '5'));
        Settings::create(array('id' => 2,'tool_tip' => 'Default Changing method for users','page'=>'1','key' => 'default_charging_method_for_users' , 'value' => '1'));
        Settings::create(array('id' => 3,'tool_tip' => 'Incase of Fixed price payment, Base price is the total amount thats charged to users','page'=>'1','key' => 'base_price' , 'value' => '50'));
        Settings::create(array('id' => 4,'tool_tip' => 'Needed only incase of time and distance based payment','page'=>'1','key' => 'price_per_unit_distance' , 'value' => '10'));
        Settings::create(array('id' => 5,'tool_tip' => 'Needed only incase of time and distance based payment','page'=>'1','key' => 'price_per_unit_time' , 'value' => '8'));
        Settings::create(array('id' => 6,'tool_tip' => 'Maximum time for provider to respond for a request','page'=>'1','key' => 'provider_timeout' , 'value' => '60'));
        Settings::create(array('id' => 7,'tool_tip' => 'Send SMS Notifications','page'=>'1','key' => 'sms_notification' , 'value' => '0'));
        Settings::create(array('id' => 8,'tool_tip' => 'Send Email Notifications','page'=>'1','key' => 'email_notification' , 'value' => '0'));
        Settings::create(array('id' => 9,'tool_tip' => 'Send Push Notifications','page'=>'1','key' => 'push_notification' , 'value' => '1'));
        Settings::create(array('id' => 10,'tool_tip' => 'Bonus credit that should be added incase if user refers another','page'=>'1','key' => 'default_referral_bonus' , 'value' => '10'));
        Settings::create(array('id' => 11,'tool_tip' => 'This mobile number will get SMS notifications about requests','page'=>'1','key' => 'admin_phone_number' , 'value' => '+917708288018'));
        Settings::create(array('id' => 12,'tool_tip' => 'This address will get Email notifications about requests','page'=>'1','key' => 'admin_email_address' , 'value' => 'prabakaranbs@gmail.com'));
        
       
        Settings::create(array('id' => 13,'tool_tip' => 'This Template will be used to notify user by SMS when a provider the accepts request','page'=>'2','key' => 'sms_when_provider_accepts' , 'value' => 'Hi %user%, Your request is accepted by %driver%. You can reach him by %driver_mobile%'));
        Settings::create(array('id' => 14,'tool_tip' => 'This Template will be used to notify user by SMS when a provider the arrives','page'=>'2','key' => 'sms_when_provider_arrives' , 'value' => 'Hi %user%, The %driver% has arrived at your location.You can reach user by %driver_mobile%'));
        Settings::create(array('id' => 15,'tool_tip' => 'This Template will be used to notify user by SMS when a provider the completes the service','page'=>'2','key' => 'sms_when_provider_completes_job' , 'value' => 'Hi %user%, Your request is successfully completed by %driver%. Your Bill amount id %amount%'));
        Settings::create(array('id' => 16,'tool_tip' => 'This Template will be used to notify admin by SMS when a new request is created','page'=>'2','key' => 'sms_request_created' , 'value' => 'Request id %id% is created by %user%, You can reach him by %user_mobile%'));
        Settings::create(array('id' => 17,'tool_tip' => 'This Template will be used to notify admin by SMS when a request remains unanswered by all providers','page'=>'2','key' => 'sms_request_unanswered' , 'value' => 'Request id %id% created by %user% is left unanswered, You can reach user by %user_mobile%'));
        Settings::create(array('id' => 18,'tool_tip' => 'This Template will be used to notify admin by SMS when a request is completed','page'=>'2','key' => 'sms_request_completed' , 'value' => 'Request id %id% created by %user% is completed, You can reach user by %user_mobile%'));
        Settings::create(array('id' => 19,'tool_tip' => 'This Template will be used to notify admin by SMS when payment is generated for a request','page'=>'2','key' => 'sms_payment_generated' , 'value' => 'Payment for Request id %id% is generated.'));
        
        Settings::create(array('id' => 20,'tool_tip' => 'This Template will be used to notify users and providers by email when they reset their password','page'=>'3','key' => 'email_forgot_password' , 'value' => 'Your New Password is %password%. Please dont forget to change the password once you log in next time.'));
        Settings::create(array('id' => 21,'tool_tip' => 'This Template will be used for welcome mail to provider','page'=>'3','key' => 'email_walker_new_registration' , 'value' => 'Welcome on Board %name%'));
        Settings::create(array('id' => 22,'tool_tip' => 'This Template will be used for welcome mail to user','page'=>'3','key' => 'email_owner_new_registration' , 'value' => 'Welcome on Board %name%'));
        Settings::create(array('id' => 23,'tool_tip' => 'This Template will be used notify admin by email when a new request is created','page'=>'3','key' => 'email_new_request' , 'value' => 'New Requeest %id% is created. Follow the request through %url%'));
        Settings::create(array('id' => 24,'tool_tip' => 'This Template will be used notify admin by email when a request remains unanswerd by all providers','page'=>'3','key' => 'email_request_unanswered' , 'value' => 'Requeest %id% has beed declined by all providers. Follow the request through %url%'));
        Settings::create(array('id' => 25,'tool_tip' => 'This Template will be used notify admin by email when a request is completed','page'=>'3','key' => 'email_request_finished' , 'value' => 'Requeest %id% is finished. Follow the request through %url%'));
        Settings::create(array('id' => 26,'tool_tip' => 'This Template will be used notify admin by email when a client is charged for a request','page'=>'3','key' => 'email_payment_charged' , 'value' => 'Requeest %id% is finished. Follow the request through %url%'));
        Settings::create(array('id' => 27,'tool_tip' => 'This Template will be used notify user by email when invoice is generated','page'=>'3','key' => 'email_invoice_generated_user' , 'value' => 'invoice for Request id %id% is generated. Total amount is %amount%'));
        Settings::create(array('id' => 28,'tool_tip' => 'This Template will be used notify provider by email when invoice is generated','page'=>'3','key' => 'email_invoice_generated_provider' , 'value' => 'invoice for Request id %id% is generated. Total amount is %amount%'));
        Settings::create(array('id' => 29,'tool_tip' => 'This is latitude for the map center','page'=>'1','key' => 'map_center_latitude' , 'value' => '0'));
        Settings::create(array('id' => 30,'tool_tip' => 'This is longitude for the map center','page'=>'1','key' => 'map_center_longitude' , 'value' => '0'));
        Settings::create(array('id' => 31,'tool_tip' => 'This is the default unit of distance','page'=>'1','key' => 'default_distance_unit' , 'value' => '0'));
        Settings::create(array('id' => 32,'tool_tip' => 'Automatically assign provider or manually select from a displayed list of all providers','page'=>'4','key' => 'provider_selection' , 'value' => '1'));
        Settings::create(array('id' => 33,'tool_tip' => 'Service Fee Amount','page'=>'4','key' => 'service_fee' , 'value' => '10'));

    }

}