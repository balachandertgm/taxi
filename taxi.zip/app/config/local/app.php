<?php

return array(

    'debug' => true,

    'default_payment' => 'stripe',

    'stripe_secret_key' => 'sk_test_KEPYYC7Y9i311HHQbKI8b1hA',
    'stripe_publishable_key' => 'pk_test_IfOcjJN6AvUEYzTR0IDIek1G',
    'braintree_environment' => 'sandbox',
    'braintree_merchant_id' => '5zpt25spmsm6rhqt',
    'braintree_public_key' => 'sqtd6jqd3jqr9cs5',
    'braintree_private_key' => 'e44fdf58a7bdc163c9ad9bb3bf8e914f',
    'braintree_cse' => 'MIIBCgKCAQEAxPbGgtMzcQZ2Rm1Fr+HUh7CzAAWghFF4c+y1XqtD5v5DT4kbUxAvpxTO3qa4iqd7vEAdeFYCN5wZnWczE8oLI1SmeFKwW022w10TBk0KdDfTHTvqsyqLZyAz82x7Z+wrhQl43jdvRUQOL73lufYM1QEcqibRruASt8kp/W37wB+yKLaEBsArz2zMTJ1w0IdfWCoIVFRVdTm018q3WXjnr3ujEJIk1A09marEfLjeG5LKOkj2odrRCe5IVa9H6/eLKmO4DbLYrwSWOaI1RfjX3HqkwLpKMjnwTJmAMm2jKX0hX6Aez4IMHMYMzJN76YtPuRnASZl2YDrha8Zvq/bpgwIDAQAB',
    'masterMerchantAccountId' => 'rq2mrxmt99g7ycxk',
);
